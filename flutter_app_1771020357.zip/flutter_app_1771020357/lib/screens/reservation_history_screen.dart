import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ReservationHistoryScreen extends StatelessWidget {
  const ReservationHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lịch sử Đặt bàn - 1771020630'),
        backgroundColor: Colors.orange,
      ),
      body: StreamBuilder<QuerySnapshot>(
        // Lấy toàn bộ đơn đặt bàn, sắp xếp theo thời gian mới nhất
        stream: FirebaseFirestore.instance
            .collection('reservations')
            .orderBy('createdAt', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) return Center(child: Text('Lỗi: ${snapshot.error}'));
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snapshot.data?.docs ?? [];
          if (docs.isEmpty) {
            return const Center(child: Text('Chưa có lịch sử đặt bàn nào.'));
          }

          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final data = docs[index].data() as Map<String, dynamic>;
              final orderItems = List.from(data['orderItems'] ?? []);
              
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                child: ExpansionTile(
                  leading: Icon(
                    data['status'] == 'completed' ? Icons.check_circle : Icons.pending_actions,
                    color: data['status'] == 'completed' ? Colors.green : Colors.orange,
                  ),
                  title: Text('Khách hàng: ${data['customerId']}'),
                  subtitle: Text('Tổng: ${data['total']} VND - ${data['status']}'),
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Chi tiết món ăn:', style: TextStyle(fontWeight: FontWeight.bold)),
                          ...orderItems.map((item) => Text('- ${item['name']} x1')),
                          const Divider(),
                          Text('Ngày đặt: ${(data['reservationDate'] as Timestamp).toDate().toString()}'),
                          if (data['specialRequests'] != null)
                            Text('Yêu cầu: ${data['specialRequests']}'),
                        ],
                      ),
                    )
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}