import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/menu_item_model.dart';
import '../repositories/reservation_repository.dart';

class ReservationScreen extends StatefulWidget {
  final List<MenuItemModel> selectedItems; // Danh sách món đã chọn
  const ReservationScreen({super.key, required this.selectedItems});

  @override
  State<ReservationScreen> createState() => _ReservationScreenState();
}

class _ReservationScreenState extends State<ReservationScreen> {
  final _resRepo = ReservationRepository();
  final _customerIdController = TextEditingController();
  final _guestsController = TextEditingController(text: "1");
  final _requestController = TextEditingController();
  DateTime _selectedDate = DateTime.now();

  // Tính tổng tiền các món đã chọn
  double get _totalPrice {
    return widget.selectedItems.fold(0, (sum, item) => sum + item.price);
  }

  void _confirmReservation() async {
    if (_customerIdController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Vui lòng nhập Mã khách hàng')));
      return;
    }

    // Chuyển danh sách món thành dạng List<Map> để lưu vào Firestore
    List<Map<String, dynamic>> orderItems = widget.selectedItems.map((item) => {
      'name': item.name,
      'price': item.price,
      'quantity': 1,
    }).toList();

    await _resCollection.add({
      'customerId': _customerIdController.text,
      'reservationDate': Timestamp.fromDate(_selectedDate),
      'numberOfGuests': int.parse(_guestsController.text),
      'specialRequests': _requestController.text,
      'orderItems': orderItems,
      'total': _totalPrice,
      'status': 'pending',
      'paymentStatus': 'pending',
      'createdAt': Timestamp.now(),
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đặt bàn thành công!')));
      Navigator.popUntil(context, (route) => route.isFirst);
    }
  }

  // Tạm thời khai báo Collection ở đây để code chạy ngay
  final CollectionReference _resCollection = FirebaseFirestore.instance.collection('reservations');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Xác nhận Đặt bàn')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Tổng tiền: $_totalPrice VND', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.red)),
          const Divider(),
          TextField(controller: _customerIdController, decoration: const InputDecoration(labelText: 'Mã khách hàng (đã đăng ký)')),
          TextField(controller: _guestsController, decoration: const InputDecoration(labelText: 'Số lượng khách'), keyboardType: TextInputType.number),
          TextField(controller: _requestController, decoration: const InputDecoration(labelText: 'Yêu cầu đặc biệt')),
          ListTile(
            title: Text("Ngày đặt: ${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}"),
            trailing: const Icon(Icons.calendar_today),
            onTap: () async {
              DateTime? picked = await showDatePicker(
                context: context,
                initialDate: _selectedDate,
                firstDate: DateTime.now(),
                lastDate: DateTime(2026),
              );
              if (picked != null) setState(() => _selectedDate = picked);
            },
          ),
          const SizedBox(height: 10),
          const Text('Món đã chọn:', style: TextStyle(fontWeight: FontWeight.bold)),
          ...widget.selectedItems.map((item) => ListTile(
            title: Text(item.name),
            trailing: Text('${item.price} VND'),
          )),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: _confirmReservation,
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orange, minimumSize: const Size(double.infinity, 50)),
            child: const Text('HOÀN TẤT ĐẶT BÀN', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}