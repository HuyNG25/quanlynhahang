import 'package:cloud_firestore/cloud_firestore.dart';

class ReservationModel {
  String reservationId;
  String customerId;
  Timestamp reservationDate;
  int numberOfGuests;
  String? tableNumber; // Có thể để trống [cite: 49]
  String status;
  List<Map<String, dynamic>> orderItems; // Mảng các món ăn lồng nhau [cite: 54]
  double total;
  String paymentStatus;

  ReservationModel({
    required this.reservationId,
    required this.customerId,
    required this.reservationDate,
    required this.numberOfGuests,
    this.tableNumber,
    required this.status,
    required this.orderItems,
    required this.total,
    required this.paymentStatus,
  });

  factory ReservationModel.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return ReservationModel(
      reservationId: doc.id,
      customerId: data['customerId'] ?? '',
      reservationDate: data['reservationDate'] ?? Timestamp.now(),
      numberOfGuests: data['numberOfGuests'] ?? 1,
      tableNumber: data['tableNumber'],
      status: data['status'] ?? 'pending',
      orderItems: List<Map<String, dynamic>>.from(data['orderItems'] ?? []),
      total: (data['total'] ?? 0.0).toDouble(),
      paymentStatus: data['paymentStatus'] ?? 'pending',
    );
  }
}