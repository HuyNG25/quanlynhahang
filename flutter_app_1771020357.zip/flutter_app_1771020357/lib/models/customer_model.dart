import 'package:cloud_firestore/cloud_firestore.dart';

class CustomerModel {
  String customerId;
  String email;
  String fullName;
  String phoneNumber;
  String address;
  List<String> preferences;
  int loyaltyPoints;
  Timestamp createdAt;
  bool isActive;

  CustomerModel({
    required this.customerId,
    required this.email,
    required this.fullName,
    required this.phoneNumber,
    required this.address,
    required this.preferences,
    this.loyaltyPoints = 0,
    required this.createdAt,
    required this.isActive,
  });

  // Chuyển đổi từ Firestore Document sang Model (Để đọc dữ liệu)
  factory CustomerModel.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return CustomerModel(
      customerId: doc.id,
      email: data['email'] ?? '',
      fullName: data['fullName'] ?? '',
      phoneNumber: data['phoneNumber'] ?? '',
      address: data['address'] ?? '',
      preferences: List<String>.from(data['preferences'] ?? []),
      loyaltyPoints: data['loyaltyPoints'] ?? 0,
      createdAt: data['createdAt'] ?? Timestamp.now(),
      isActive: data['isActive'] ?? true,
    );
  }

  // QUAN TRỌNG: Thêm hàm này để sửa lỗi "toMap isn't defined"
  Map<String, dynamic> toMap() {
    return {
      'email': email,
      'fullName': fullName,
      'phoneNumber': phoneNumber,
      'address': address,
      'preferences': preferences,
      'loyaltyPoints': loyaltyPoints,
      'createdAt': createdAt,
      'isActive': isActive,
    };
  }
}