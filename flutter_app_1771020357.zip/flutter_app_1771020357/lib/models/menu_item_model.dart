import 'package:cloud_firestore/cloud_firestore.dart';

class MenuItemModel {
  String itemId;
  String name;
  String description;
  String category;
  double price;
  String imageUrl;
  List<String> ingredients; // Mảng nguyên liệu [cite: 34]
  bool isVegetarian;
  bool isSpicy;
  int preparationTime;
  bool isAvailable;
  double rating;

  MenuItemModel({
    required this.itemId,
    required this.name,
    required this.description,
    required this.category,
    required this.price,
    required this.imageUrl,
    required this.ingredients,
    required this.isVegetarian,
    required this.isSpicy,
    required this.preparationTime,
    required this.isAvailable,
    required this.rating,
  });

  factory MenuItemModel.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return MenuItemModel(
      itemId: doc.id,
      name: data['name'] ?? '',
      description: data['description'] ?? '',
      category: data['category'] ?? '',
      price: (data['price'] ?? 0.0).toDouble(),
      imageUrl: data['imageUrl'] ?? '',
      ingredients: List<String>.from(data['ingredients'] ?? []),
      isVegetarian: data['isVegetarian'] ?? false,
      isSpicy: data['isSpicy'] ?? false,
      preparationTime: data['preparationTime'] ?? 0,
      isAvailable: data['isAvailable'] ?? true,
      rating: (data['rating'] ?? 0.0).toDouble(),
    );
  }
}