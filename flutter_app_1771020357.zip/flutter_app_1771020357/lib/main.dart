import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/menu_screen.dart'; 

class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Menu'),
      ),
      body: const Center(
        child: Text('Welcome to the Restaurant Menu!'),
      ),
    );
  }
}
void main() async {
  // Bắt buộc phải có dòng này khi sử dụng async trong hàm main
  WidgetsFlutterBinding.ensureInitialized();

  // Khởi tạo Firebase với thông số bạn đã cung cấp
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: "AIzaSyDG0s_Bx_m7UAw_bnOgdJ3-XF92NogKqSo",
    authDomain: "flutter-firebase-1771020357.firebaseapp.com",
    projectId: "flutter-firebase-1771020357",
    storageBucket: "flutter-firebase-1771020357.firebasestorage.app",
    messagingSenderId: "239022873408",
    appId: "1:239022873408:web:e36bd88c1aa3d69eff78a5",
    measurementId: "G-J4LLK82Q3F"
    ),
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Restaurant App - 1771020630',
      theme: ThemeData(
        primarySwatch: Colors.orange,
        useMaterial3: true,
      ),
      // Màn hình đầu tiên khi mở app là màn hình thực đơn
      home: const MenuScreen(),
    );
  }
}