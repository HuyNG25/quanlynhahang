import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/customer_model.dart';

class CustomerRepository {
  final CollectionReference _customerCollection = 
      FirebaseFirestore.instance.collection('customers');

  Future<void> addCustomer(CustomerModel customer) async {
    // Sau khi thêm toMap() ở Bước 1, dòng này sẽ hết lỗi gạch đỏ
    await _customerCollection.doc(customer.customerId).set(customer.toMap());
  }

  Future<CustomerModel?> getCustomerById(String id) async {
    DocumentSnapshot doc = await _customerCollection.doc(id).get();
    if (doc.exists) return CustomerModel.fromFirestore(doc);
    return null;
  }

  Future<void> updateLoyaltyPoints(String customerId, int points) async {
    await _customerCollection.doc(customerId).update({
      'loyaltyPoints': FieldValue.increment(points),
    });
  }
}