import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/menu_item_model.dart';

class MenuItemRepository {
  final CollectionReference _menuCollection = 
      FirebaseFirestore.instance.collection('menu_items');

  // 3. Lấy tất cả MenuItems (2 điểm)
  Stream<List<MenuItemModel>> getMenuItems() {
    return _menuCollection.snapshots().map((snapshot) {
      return snapshot.docs.map((doc) => MenuItemModel.fromFirestore(doc)).toList();
    });
  }

  // 5. Lọc MenuItems theo danh mục, chay hoặc cay (3 điểm)
  Query getFilteredItems({String? category, bool? isVegetarian, bool? isSpicy}) {
    Query query = _menuCollection;
    
    // Nếu có truyền category thì thêm điều kiện lọc
    if (category != null) {
      query = query.where('category', isEqualTo: category);
    }
    
    // Lọc theo món chay
    if (isVegetarian != null) {
      query = query.where('isVegetarian', isEqualTo: isVegetarian);
    }
    
    // Lọc theo món cay
    if (isSpicy != null) {
      query = query.where('isSpicy', isEqualTo: isSpicy);
    }
    
    return query;
  }
}