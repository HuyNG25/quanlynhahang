import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/reservation_model.dart';

class ReservationRepository {
  final CollectionReference _resCollection = 
      FirebaseFirestore.instance.collection('reservations');

  // 1. Đặt Bàn (5 điểm) - Trạng thái mặc định là "pending"
  Future<void> createReservation(String customerId, Timestamp date, int guests, String? requests) async {
    await _resCollection.add({
      'customerId': customerId,
      'reservationDate': date,
      'numberOfGuests': guests,
      'specialRequests': requests,
      'status': 'pending',
      'orderItems': [],
      'total': 0.0, // Tổng tiền ban đầu là 0
      'paymentStatus': 'pending',
      'createdAt': Timestamp.now(),
    });
  }

  // 4. Thanh toán (3 điểm)
  Future<void> payReservation(String reservationId, String method) async {
    await _resCollection.doc(reservationId).update({
      'paymentStatus': 'paid',
      'status': 'completed',
      'paymentMethod': method,
      'updatedAt': Timestamp.now(),
    });
  }
}